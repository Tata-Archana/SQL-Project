-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: nursery
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gardening_tool`
--

DROP TABLE IF EXISTS `gardening_tool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gardening_tool` (
  `gardening_tool_id` int NOT NULL AUTO_INCREMENT,
  `gardening_tool_name` varchar(255) NOT NULL,
  `gardening_tool_type` varchar(255) DEFAULT NULL,
  `gardening_tool_description` text,
  `gardening_tool_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`gardening_tool_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gardening_tool`
--

LOCK TABLES `gardening_tool` WRITE;
/*!40000 ALTER TABLE `gardening_tool` DISABLE KEYS */;
INSERT INTO `gardening_tool` VALUES (6,'Trowel','','A hand tool with a pointed, scoop-shaped blade used for digging small holes for planting or transplanting seedlings. Trowels can \n    also be used for removing weeds and cultivating soil in small areas.',15.00),(7,'Garden fork','Digging tool','A tool with several pointed prongs used for loosening soil \n    and removing weeds. Garden forks can also be used for turning compost piles.',13.30),(8,'Pruning shears','Pruning tool','known as secateurs, pruning shears are used for cutting small branches and stems. \n    They come in various sizes and styles, including bypass, anvil, and ratchet pruners.',21.00),(9,'Garden gloves','Protective tool','Protective gloves worn while working in the garden to prevent blisters and cuts. Garden gloves come in\n    various materials, including leather, rubber, and cotton.',10.99),(10,'Garden shovel','Digging tool','A tool with a long handle and a scoop-shaped blade used for digging, planting, and moving soil. Garden shovels come in various \n    styles, including spade shovels, round point shovels, and square point shovels.',20.00);
/*!40000 ALTER TABLE `gardening_tool` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-19 11:41:14
