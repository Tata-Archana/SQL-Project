-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: nursery
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plant_requirement`
--

DROP TABLE IF EXISTS `plant_requirement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plant_requirement` (
  `requirement_id` int NOT NULL AUTO_INCREMENT,
  `requirement_name` varchar(255) NOT NULL,
  `requirement_description` text,
  PRIMARY KEY (`requirement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plant_requirement`
--

LOCK TABLES `plant_requirement` WRITE;
/*!40000 ALTER TABLE `plant_requirement` DISABLE KEYS */;
INSERT INTO `plant_requirement` VALUES (1,'Full Sunlight','This plant requires full sunlight for at least 6 hours a day.'),(2,'Partial Sunlight','Requires 3-6 hours of direct sunlight per day.	'),(3,'Shade','Requires no direct sunlight but can tolerate bright, indirect light.	'),(4,'Temperature-sensitive','Requires a specific temperature range to thrive, and may not survive extreme temperatures outside that range.'),(5,'Heat-tolerant','Can tolerate high temperatures and direct sunlight.'),(6,'Cold-hardy','Can tolerate temperatures below freezing.'),(7,'Pest-resistant','Resistant to common plant pests, such as aphids, spider mites, and whiteflies.'),(8,'Disease-resistant','Resistant to common plant diseases, such as powdery mildew, leaf spot, and blight.'),(9,'Natural pest control	','Attracts beneficial insects or repels harmful pests, such as planting companion plants or using natural remedies.'),(10,'Dry soil','Requires infrequent watering, allowing soil to dry out between watering.	'),(13,'Moist soil	','Requires regular watering, keeping soil consistently moist.	'),(14,'Well-drained soil	','Requires watering when soil is completely dry, but also needs good drainage to prevent standing water.	'),(15,'Fertilizer','This plant requires regular fertilization every two weeks.'),(16,'Fertilizer Type','This plant requires a balanced, water-soluble fertilizer with equal parts of nitrogen, phosphorus, and potassium.'),(17,'Fertilizer Quantity','This plant requires 1 teaspoon of fertilizer diluted in 1 gallon of water for every feeding.');
/*!40000 ALTER TABLE `plant_requirement` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-19 11:41:14
